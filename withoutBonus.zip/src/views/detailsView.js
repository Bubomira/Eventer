import { html, nothing } from "../../node_modules/lit-html/lit-html.js";
import { getOneEvent } from "../services/eventsServices.js";

const detailsTemplate = (event,isOwner)=>html`

        <!-- Details page -->
        <section id="details">
          <div id="details-wrapper">
            <img id="details-img" src="${event.imageUrl}" alt="example1" />
            <p id="details-title">${event.name}</p>
            <p id="details-category">
              Category: <span id="categories">${event.category}</span>
            </p>
            <p id="details-date">
              Date:<span id="date">${event.date}</span></p>
            <div id="info-wrapper">
              <div id="details-description">
                <span>${event.description}</span>
              </div>

            </div>

            <h3>Going: <span id="go">0</span> times.</h3>

            <div id="action-buttons">
                ${isOwner?
                html` 
                <a href="/edit/${event._id}" id="edit-btn">Edit</a>
              <a href="/delete/${event._id}" id="delete-btn">Delete</a> `
              :nothing}  

              <!-- Bonus - Only for logged-in users ( not authors )
              <a href="" id="go-btn">Going</a> -->
            </div>
          </div>
        </section>
`

export const detailsView = (ctx)=>{
    getOneEvent(ctx.params.eventId)
    .then(event=>{
        ctx.render(detailsTemplate(event,event._ownerId==ctx.user?._id))
    })
}